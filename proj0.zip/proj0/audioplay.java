public class audioplay {
	private static String audio = "audio/2001.mid";
	public static void main(String[] args) {
		StdAudio.loop(audio);
	}
}